% script for intergral function
function f = IntFun(t)

f = exp(-1*t^2);