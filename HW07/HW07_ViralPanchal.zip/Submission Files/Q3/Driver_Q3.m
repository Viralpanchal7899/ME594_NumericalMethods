% Driver for Q3

clear all
close all
clc

x = 2;
ef = ErrorFun(x);

