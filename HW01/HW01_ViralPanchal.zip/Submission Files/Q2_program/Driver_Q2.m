%% Driver for Q2
% function file name - intTObina.m

% Test case 1 | d = 81
fprintf('Binary when d = 81 \n');
b = intTObina(81);

% Test case 2 | d = 30952
fprintf('Binary when d = 30952 \n');
b = intTObina(30952);

% Test case 3 | d = 1500000
fprintf('Binary when d = 1500000 \n');
b = intTObina(1500000);

