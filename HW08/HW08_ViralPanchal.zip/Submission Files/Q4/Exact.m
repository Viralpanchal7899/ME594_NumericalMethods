% Script for exact solution
function f = Exact(t)

f = 350*(1-exp(-0.2*t))/(7-5*exp(-0.2*t));

end
