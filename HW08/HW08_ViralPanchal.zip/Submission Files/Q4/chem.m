function f = chem(t,y)

k = 0.01;
a = 70;
b = 50;
f = k*(a-y)*(b-y);

end
