% GP for Newton solver
function f = GZ_NS(z,x_k_p1,h)

f = 3*x_k_p1*z^2+1;

end