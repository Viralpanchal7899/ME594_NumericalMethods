% Euler function

function f = Euler(x,y)
f = x-(x*y)/2;
end
