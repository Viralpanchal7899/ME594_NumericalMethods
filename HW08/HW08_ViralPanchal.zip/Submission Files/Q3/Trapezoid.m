% Trapezoid function

function f = Trapezoid(x_k,x_k_p1,y_k,h)
f = (y_k+h/2*(x_k+x_k_p1-x_k*y_k/2))/(1+h/4*x_k_p1);
end

