% Q2 driver

% Matrix A given 
A = [4 -1 3 2
    -8 0 -3 -3.5
    2 -3.5 10 3.75
    -8 -4 1 -0.5]

[L,U] = LU_decompose(A)