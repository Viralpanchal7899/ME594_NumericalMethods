% Q4 driver

a = [2 3 2];
b = [1 -1 -4 6];
c = [1 5 2];
rhs = [5 -9 19 2];

x = thomas_alg(a,b,c,rhs)