Just run the LS_generic.m to view the output. 
NOTE: This program runs irrespective of errror generated upto order 20.