Just run LS_generic.m to view the output. 
NOTE: The condition to stop in this program in MSE<Tol
