This folder has hard coded LS method for first few polynomial orders. Run each indivudually to view the output.
